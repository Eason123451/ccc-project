from elasticsearch8 import Elasticsearch
import json
from flask import current_app

def main():
    client = Elasticsearch(
        'https://elasticsearch-master.elastic.svc.cluster.local:9200',
        verify_certs=False,
        ssl_show_warn=False,
        basic_auth=('elastic', 'epheli0AJ4eir9xaiM2muqu6eehee4oh')
    )

    try:
        info = client.info()
        current_app.logger.info("Connected to Elasticsearch")
        current_app.logger.info(info)
        return info
    except Exception as e:
        error_message = f"Error: {str(e)}"
        current_app.logger.error(error_message)
        return json.dumps({"error": error_message}, indent=2)